export class AppId {
     appid?:number;
}