import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-data-by-id',
  templateUrl: './delete-data-by-id.component.html',
  styleUrls: ['./delete-data-by-id.component.css']
})
export class DeleteDataByIdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
