export class User {
        mobilenumber?:String;
        pannumber?:String;
        firstname?:String;
        middlename?:String;
        lastname?:String;
        fathername?:String;
        personalemail?:String;
        gender?:String;
        dob?:Date;
        pincode?:String;
        kyccity?:String;
        kycstate?:String;
}